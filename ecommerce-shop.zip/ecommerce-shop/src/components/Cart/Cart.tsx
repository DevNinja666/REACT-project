import React from 'react';
import { Link } from 'react-router-dom';
import { useAppSelector } from '../../store/hooks';
import CartItem from '../CartItem/CartItem';

const Cart: React.FC = () => {
  const cartItems = useAppSelector((state) => state.cart.items);
  const total = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-8 sm:py-12">
        <p className="text-gray-600 text-base sm:text-lg mb-4">Your cart is empty</p>
        <Link
          to="/"
          className="inline-block bg-blue-500 text-white py-2.5 px-6 rounded-lg hover:bg-blue-600 transition-colors text-sm sm:text-base"
        >
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Shopping Cart</h2>
      <div className="space-y-3 sm:space-y-4">
        {cartItems.map((item) => (
          <CartItem key={item.product.id} item={item} />
        ))}
      </div>
      <div className="mt-6 sm:mt-8 p-4 sm:p-5 bg-gray-50 rounded-xl">
        <div className="flex justify-between items-center mb-4">
          <span className="text-lg sm:text-xl font-semibold">Total:</span>
          <span className="text-xl sm:text-2xl font-bold text-blue-600">
            ${total.toFixed(2)}
          </span>
        </div>
        <button className="w-full bg-blue-500 text-white py-3 px-6 rounded-lg hover:bg-blue-600 transition-colors font-semibold text-sm sm:text-base">
          Checkout
        </button>
      </div>
    </div>
  );
};

export default Cart;

