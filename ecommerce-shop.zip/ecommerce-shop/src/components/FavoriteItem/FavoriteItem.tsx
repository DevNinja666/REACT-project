import React from 'react';
import { Product } from '../../types';
import { useAppDispatch } from '../../store/hooks';
import { removeFromFavorites } from '../../store/favoritesSlice';
import { addToCart } from '../../store/cartSlice';

interface FavoriteItemProps {
  product: Product;
}

const FavoriteItem: React.FC<FavoriteItemProps> = ({ product }) => {
  const dispatch = useAppDispatch();

  const handleRemove = () => {
    dispatch(removeFromFavorites(product.id));
  };

  const handleAddToCart = () => {
    dispatch(addToCart(product));
  };

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 bg-gray-50 p-4 sm:p-5 rounded-xl shadow-md">
      <img
        src={product.image}
        alt={product.title}
        className="w-full sm:w-24 h-48 sm:h-24 object-cover rounded-lg"
      />
      <div className="flex-1 w-full sm:w-auto">
        <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-1">{product.title}</h3>
        <p className="text-lg sm:text-xl font-bold text-blue-600">${product.price.toFixed(2)}</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
        <button
          onClick={handleAddToCart}
          className="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors text-sm sm:text-base"
        >
          Add to Cart
        </button>
        <button
          onClick={handleRemove}
          className="bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 transition-colors text-sm sm:text-base"
        >
          Remove
        </button>
      </div>
    </div>
  );
};

export default FavoriteItem;

