import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { logout } from '../../store/authSlice';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { isAuthenticated, currentUser } = useAppSelector((state) => state.auth);
  const cartItems = useAppSelector((state) => state.cart.items);
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <nav className="bg-blue-600 shadow-lg rounded-2xl mx-2 sm:mx-4 md:mx-6 lg:mx-8 mt-2 sm:mt-4">
        <div className="container mx-auto px-3 sm:px-4 lg:px-6">
          <div className="flex flex-col sm:flex-row justify-between items-center py-3 sm:py-0 sm:h-16 gap-3 sm:gap-0">
            <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4 lg:space-x-8 w-full sm:w-auto">
              <Link to="/" className="text-lg sm:text-xl font-bold text-white">
                Ecommerce Shop
              </Link>
              <div className="flex flex-wrap justify-center sm:justify-start gap-2 sm:gap-4">
                <Link
                  to="/"
                  className="text-sm sm:text-base text-white hover:text-blue-200 transition-colors px-2 py-1 rounded-lg hover:bg-blue-700"
                >
                  Home
                </Link>
                <Link
                  to="/favorites"
                  className="text-sm sm:text-base text-white hover:text-blue-200 transition-colors px-2 py-1 rounded-lg hover:bg-blue-700"
                >
                  Favorites
                </Link>
                {isAuthenticated && (
                  <Link
                    to="/add-product"
                    className="text-sm sm:text-base text-white hover:text-blue-200 transition-colors px-2 py-1 rounded-lg hover:bg-blue-700"
                  >
                    Add Product
                  </Link>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 w-full sm:w-auto justify-center sm:justify-end">
              <Link
                to="/cart"
                className="relative text-white hover:text-blue-200 transition-colors p-2"
              >
                <svg
                  className="w-5 h-5 sm:w-6 sm:h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Link>
              {isAuthenticated ? (
                <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-3 lg:space-x-4">
                  <span className="text-xs sm:text-sm lg:text-base text-white hidden sm:inline">Hello, {currentUser?.name}</span>
                  <span className="text-xs sm:text-sm lg:text-base text-white sm:hidden">{currentUser?.name}</span>
                  <button
                    onClick={handleLogout}
                    className="bg-white text-blue-600 px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg hover:bg-blue-50 transition-colors text-sm sm:text-base font-semibold"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <div className="flex space-x-2">
                  <Link
                    to="/login"
                    className="bg-white text-blue-600 px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg hover:bg-blue-50 transition-colors text-sm sm:text-base font-semibold"
                  >
                    Login
                  </Link>
                  <Link
                    to="/register"
                    className="bg-blue-500 text-white px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm sm:text-base font-semibold"
                  >
                    Register
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
      <main className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8 flex-1">{children}</main>
    </div>
  );
};

export default Layout;

