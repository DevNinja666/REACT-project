import React from 'react';
import { useAppSelector } from '../../store/hooks';
import ProductCard from '../../components/ProductCard/ProductCard';

const Home: React.FC = () => {
  const products = useAppSelector((state) => state.products.products);

  return (
    <div>
      <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8 text-center">Product Catalog</h1>
      {products.length === 0 ? (
        <div className="text-center py-8 sm:py-12">
          <p className="text-gray-600 text-base sm:text-lg">No products available yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;

