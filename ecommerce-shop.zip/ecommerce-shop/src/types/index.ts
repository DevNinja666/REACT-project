export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Product {
  id: string;
  title: string;
  price: number;
  image: string;
  ownerId: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

