# Ecommerce Shop

A full-featured e-commerce SPA built with React, Redux Toolkit, React Router, and Tailwind CSS.

## Features

- User authentication (Register/Login)
- Product catalog with add/edit functionality
- Shopping cart with quantity management
- Favorites system
- Protected routes for authenticated users
- Product ownership management
- LocalStorage persistence

## Tech Stack

- React 18
- Redux Toolkit
- React Router v7
- TypeScript
- Tailwind CSS
- Vite

## Installation

```bash
npm install
```

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
```

## Project Structure

```
src/
├── components/
│   ├── ProductCard/
│   ├── Cart/
│   ├── CartItem/
│   ├── FavoriteItem/
│   └── Layout/
├── pages/
│   ├── Home/
│   ├── CartPage/
│   ├── FavoritesPage/
│   ├── LoginPage/
│   ├── RegisterPage/
│   ├── AddProductPage/
│   └── EditProductPage/
├── store/
│   ├── authSlice.ts
│   ├── productsSlice.ts
│   ├── cartSlice.ts
│   ├── favoritesSlice.ts
│   ├── store.ts
│   └── hooks.ts
├── types/
│   └── index.ts
├── App.tsx
└── main.tsx
```

## Routes

- `/` - Home page (product catalog)
- `/cart` - Shopping cart
- `/favorites` - Favorites list
- `/login` - Login page
- `/register` - Registration page
- `/add-product` - Add new product (protected)
- `/edit/:id` - Edit product (protected, owner only)

