import React from 'react';
import { CartItem as CartItemType } from '../../types';
import { useAppDispatch } from '../../store/hooks';
import { updateQuantity, removeFromCart } from '../../store/cartSlice';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const dispatch = useAppDispatch();

  const handleQuantityChange = (newQuantity: number) => {
    dispatch(updateQuantity({ productId: item.product.id, quantity: newQuantity }));
  };

  const handleRemove = () => {
    dispatch(removeFromCart(item.product.id));
  };

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 bg-gray-50 p-4 sm:p-5 rounded-xl shadow-md">
      <img
        src={item.product.image}
        alt={item.product.title}
        className="w-full sm:w-24 h-48 sm:h-24 object-cover rounded-lg"
      />
      <div className="flex-1 w-full sm:w-auto">
        <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-1">{item.product.title}</h3>
        <p className="text-sm sm:text-base text-gray-600">${item.product.price.toFixed(2)}</p>
      </div>
      <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleQuantityChange(item.quantity - 1)}
            className="w-8 h-8 sm:w-10 sm:h-10 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors text-sm sm:text-base"
          >
            -
          </button>
          <span className="w-12 text-center font-semibold text-sm sm:text-base">{item.quantity}</span>
          <button
            onClick={() => handleQuantityChange(item.quantity + 1)}
            className="w-8 h-8 sm:w-10 sm:h-10 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors text-sm sm:text-base"
          >
            +
          </button>
        </div>
        <div className="text-right sm:text-left">
          <p className="text-base sm:text-lg font-semibold text-gray-800">
            ${(item.product.price * item.quantity).toFixed(2)}
          </p>
          <button
            onClick={handleRemove}
            className="text-red-500 hover:text-red-700 mt-1 text-xs sm:text-sm"
          >
            Remove
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartItem;

