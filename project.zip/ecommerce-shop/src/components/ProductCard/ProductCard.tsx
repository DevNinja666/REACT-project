import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Product } from '../../types';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { addToCart } from '../../store/cartSlice';
import { addToFavorites, removeFromFavorites } from '../../store/favoritesSlice';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { currentUser, isAuthenticated } = useAppSelector((state) => state.auth);
  const favorites = useAppSelector((state) => state.favorites.products);
  const isFavorite = favorites.some((p) => p.id === product.id);
  const canEdit = isAuthenticated && currentUser && product.ownerId === currentUser.id;

  const handleAddToCart = () => {
    dispatch(addToCart(product));
  };

  const handleToggleFavorite = () => {
    if (isFavorite) {
      dispatch(removeFromFavorites(product.id));
    } else {
      dispatch(addToFavorites(product));
    }
  };

  const handleEdit = () => {
    navigate(`/edit/${product.id}`);
  };

  return (
    <div className="bg-gray-50 rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-48 sm:h-56 md:h-64 object-cover"
        />
        <button
          onClick={handleToggleFavorite}
          className={`absolute top-2 right-2 p-2 rounded-full ${
            isFavorite
              ? 'bg-red-500 text-white'
              : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
          } transition-colors`}
        >
          <svg
            className="w-5 h-5 sm:w-6 sm:h-6"
            fill={isFavorite ? 'currentColor' : 'none'}
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
            />
          </svg>
        </button>
      </div>
      <div className="p-3 sm:p-4">
        <h3 className="text-lg sm:text-xl font-semibold mb-2 text-gray-800 line-clamp-2">{product.title}</h3>
        <p className="text-xl sm:text-2xl font-bold text-blue-600 mb-3 sm:mb-4">${product.price.toFixed(2)}</p>
        <div className="flex flex-col gap-2">
          <button
            onClick={handleAddToCart}
            className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors text-sm sm:text-base"
          >
            Add to Cart
          </button>
          {canEdit && (
            <button
              onClick={handleEdit}
              className="w-full bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors text-sm sm:text-base"
            >
              Edit
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;

