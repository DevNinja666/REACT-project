import React from 'react';
import Cart from '../../components/Cart/Cart';

const CartPage: React.FC = () => {
  return (
    <div className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8">
      <Cart />
    </div>
  );
};

export default CartPage;

