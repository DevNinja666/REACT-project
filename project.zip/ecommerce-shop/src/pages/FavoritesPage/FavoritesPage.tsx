import React from 'react';
import { useAppSelector } from '../../store/hooks';
import FavoriteItem from '../../components/FavoriteItem/FavoriteItem';

const FavoritesPage: React.FC = () => {
  const favorites = useAppSelector((state) => state.favorites.products);

  return (
    <div className="container mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8">
      <h1 className="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8">Favorites</h1>
      {favorites.length === 0 ? (
        <div className="text-center py-8 sm:py-12">
          <p className="text-gray-600 text-base sm:text-lg mb-4">Your favorites list is empty.</p>
          <p className="text-gray-500 text-sm sm:text-base">Add products to favorites to see them here.</p>
        </div>
      ) : (
        <div className="space-y-3 sm:space-y-4">
          {favorites.map((product) => (
            <FavoriteItem key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default FavoritesPage;

