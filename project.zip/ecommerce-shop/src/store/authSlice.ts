import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { User } from '../types';

interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
}

const loadAuthFromStorage = (): AuthState => {
  const stored = localStorage.getItem('auth');
  if (stored) {
    const parsed = JSON.parse(stored);
    return {
      currentUser: parsed.currentUser,
      isAuthenticated: parsed.isAuthenticated || false,
    };
  }
  return {
    currentUser: null,
    isAuthenticated: false,
  };
};

const initialState: AuthState = loadAuthFromStorage();

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    login: (state, action: PayloadAction<User>) => {
      state.currentUser = action.payload;
      state.isAuthenticated = true;
      localStorage.setItem('auth', JSON.stringify(state));
    },
    logout: (state) => {
      state.currentUser = null;
      state.isAuthenticated = false;
      localStorage.removeItem('auth');
    },
    register: (state, action: PayloadAction<User>) => {
      state.currentUser = action.payload;
      state.isAuthenticated = true;
      localStorage.setItem('auth', JSON.stringify(state));
    },
  },
});

export const { login, logout, register } = authSlice.actions;
export default authSlice.reducer;

