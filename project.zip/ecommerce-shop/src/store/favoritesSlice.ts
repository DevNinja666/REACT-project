import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Product } from '../types';

interface FavoritesState {
  products: Product[];
}

const loadFavoritesFromStorage = (): FavoritesState => {
  const stored = localStorage.getItem('favorites');
  if (stored) {
    return {
      products: JSON.parse(stored),
    };
  }
  return {
    products: [],
  };
};

const initialState: FavoritesState = loadFavoritesFromStorage();

const favoritesSlice = createSlice({
  name: 'favorites',
  initialState,
  reducers: {
    addToFavorites: (state, action: PayloadAction<Product>) => {
      const exists = state.products.some((p) => p.id === action.payload.id);
      if (!exists) {
        state.products.push(action.payload);
        localStorage.setItem('favorites', JSON.stringify(state.products));
      }
    },
    removeFromFavorites: (state, action: PayloadAction<string>) => {
      state.products = state.products.filter((p) => p.id !== action.payload);
      localStorage.setItem('favorites', JSON.stringify(state.products));
    },
  },
});

export const { addToFavorites, removeFromFavorites } = favoritesSlice.actions;
export default favoritesSlice.reducer;

