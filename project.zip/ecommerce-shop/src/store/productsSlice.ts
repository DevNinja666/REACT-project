import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Product } from '../types';

interface ProductsState {
  products: Product[];
}

const loadProductsFromStorage = (): ProductsState => {
  const stored = localStorage.getItem('products');
  if (stored) {
    return {
      products: JSON.parse(stored),
    };
  }
  return {
    products: [],
  };
};

const initialState: ProductsState = loadProductsFromStorage();

const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    addProduct: (state, action: PayloadAction<Product>) => {
      state.products.push(action.payload);
      localStorage.setItem('products', JSON.stringify(state.products));
    },
    updateProduct: (state, action: PayloadAction<Product>) => {
      const index = state.products.findIndex((p) => p.id === action.payload.id);
      if (index !== -1) {
        state.products[index] = action.payload;
        localStorage.setItem('products', JSON.stringify(state.products));
      }
    },
    deleteProduct: (state, action: PayloadAction<string>) => {
      state.products = state.products.filter((p) => p.id !== action.payload);
      localStorage.setItem('products', JSON.stringify(state.products));
    },
  },
});

export const { addProduct, updateProduct, deleteProduct } = productsSlice.actions;
export default productsSlice.reducer;

